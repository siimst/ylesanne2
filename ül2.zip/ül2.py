import pygame  # Impordib Pygame'i mooduli
import sys  # Impordib sys mooduli

# Initsialiseerib Pygame'i mootori
pygame.init()

# Määra mängu akna suurus
screen = pygame.display.set_mode([640, 480])

# Paneb akna pealkirjaks "ÜlesanneX"
pygame.display.set_caption("Ülesanne2")

# Laeb taustapildi
bg_shop = pygame.image.load("bg_shop.png")
# Skaleerib taustapildi soovitud suuruseks
bg_shop = pygame.transform.scale(bg_shop, (640, 480))

# Laeb müüja pildi
seller = pygame.image.load("seller.png")
# Skaleerib müüja pildi soovitud suuruseks
seller = pygame.transform.scale(seller, (250, 305))

# Laeb jutumulli pildi
chat = pygame.image.load("chat.png")
# Skaleerib jutumulli pildi soovitud suuruseks
chat = pygame.transform.scale(chat, (255, 210))

# Loob fonti ja määrab selle suuruse
font = pygame.font.Font(None, 32)

# Tekst jutumullis
text = "Tere, olen Siim"

# Mängu tsükkel
running = True
while running:
    for event in pygame.event.get():  # Käitleb sündmusi
        if event.type == pygame.QUIT:  # Kui kasutaja sulgeb akna
            running = False  # Lõpetab mängu tsükli ja sulgeb akna

    # Kuvab taustapildi
    screen.blit(bg_shop, (0, 0))
    # Kuvab müüja pildi
    screen.blit(seller, [108, 160])
    # Kuvab jutumulli pildi
    screen.blit(chat, [246, 65])

    # Kuvab teksti jutumullis
    text_surface = font.render(text, True, (255, 255, 255))  # Tekitab tekstipinna
    text_rect = text_surface.get_rect(center=(370, 163))  # Määrab tekstipinna asukoha
    screen.blit(text_surface, text_rect.topleft)  # Kuvab teksti ekraanile

    # Uuendab ekraani
    pygame.display.flip()

# Lõpetab Pygame'i kasutamise
pygame.quit()
# Lõpetab Pythoni käivituskeskkonna
sys.exit()
